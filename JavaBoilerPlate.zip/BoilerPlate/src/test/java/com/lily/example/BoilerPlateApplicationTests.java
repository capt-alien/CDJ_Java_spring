package com.lily.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoilerPlateApplicationTests {

	@Test
	void contextLoads() {
	}

}
